using System.Collections.Generic;
using System.Linq;
using SharpPcap;
using SharpPcap.LibPcap;

namespace Ahzkwid;

public class PacketCapture
{
	private LibPcapLiveDevice[] devices;

	public PacketCapture()
	{
		List<LibPcapLiveDevice> devices = LibPcapLiveDeviceList.Instance.ToList();
		devices = devices.FindAll(delegate(LibPcapLiveDevice dev)
		{
			string text = dev.Description.ToLower();
			return (!text.Contains("loopback") || !text.Contains("capture")) ? true : false;
		});
		for (int i = 0; i < devices.Count; i++)
		{
			devices[i].Addresses.Select((PcapAddress a) => a.Addr);
		}
		this.devices = devices.ToArray();
	}

	public void Start()
	{
		LibPcapLiveDevice[] array = devices;
		foreach (LibPcapLiveDevice obj in array)
		{
			obj.Open(DeviceModes.Promiscuous);
			obj.OnPacketArrival += delegate(object sender, SharpPcap.PacketCapture e)
			{
				_ = e.GetPacket().Data;
			};
			obj.StartCapture();
		}
	}

	public void Stop()
	{
		LibPcapLiveDevice[] array = devices;
		foreach (LibPcapLiveDevice obj in array)
		{
			obj.StopCapture();
			obj.Close();
		}
	}
}
